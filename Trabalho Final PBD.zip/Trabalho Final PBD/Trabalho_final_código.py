# -*- coding: utf-8 -*-
"""
Created on Tue Jan 21 13:33:06 2020

@author: PC
"""
#IMPORTAR O CSV 

import csv
f1 =open('ipma_201508.csv', encoding='utf-8')
f1= f1.readlines()
df=csv.reader(f1, delimiter=',')

#Criar uma matriz

matriz= list(df) 


#Matriz sem cabeçalho
l=matriz[1:]   

#Dividir a coluna Time em Data e Hora

t=[]
for i in range(len(l)):
   t.append(l[i][6])


####### Dividir coluna tempo
tempo=[]
for linha in range(0,len(t)):
    tempo= tempo +[t[linha].split('T')]

####### Atribuir tempo à respetiva data e hora
date=[]
hour=[]
for i in range(len(tempo)):
    date =date+[tempo[i][0]]
    hour =hour+[tempo[i][1]]

####### Nova matriz sem tempo e com data e hora
new=[]
for i in range(len(l)):
    new=new+[l[i][:6]+l[i][7:]+[date[i]]+[hour[i]]]

data=[]
for i in range(len(new)):
    if new[i][10] not in data:
        data+=[new[i][10]]

hora=[]
for i in range(len(new)):
    if new[i][11] not in hora:
        hora+=[new[i][11]]


# Matriz - eliminar as estações repetidas
id=[]
for i in range(len(new)):
    if l[i][9] not in id:
        id+=[l[i][9]]

nome=[]
for i in range(len(new)):
    if l[i][10] not in nome:
        nome+=[l[i][10]]

station=[]
for i in range(len(id)):
    station+=[[id[i]]+[nome[i]]]

    
lat=[]
lon=[]
for i in range(len(new)):
    lat+=[[l[i][7]]+[l[i][9]]]
    lon+=[[l[i][8]]+[l[i][9]]]

###### Nova Matriz - Final
        
matriz_pronta=[]
for i in range(len(new)):
    matriz_pronta +=[new[i][:6]+new[i][8:]]


##### listas para a longitude e latitude
    
latitude=[]
n=[]
for i in range(len(lat)):
    if lat[i][1] not in n:
        n+=[lat[i][1]]
        latitude+=[lat[i][0]]

longitude=[]
n=[]
for i in range(len(lon)):
    if lon[i][1] not in n:
        n+=[lon[i][1]]
        longitude+=[lon[i][0]]

######################################################


#Fazer Conexão ao sqlite3

import sqlite3
SqliteConnection= sqlite3.connect('PBD_Trabalho.db')
c=SqliteConnection.cursor()

#Vamos criar tabelas

c.execute('''CREATE TABLE ESTACAO (ID INTEGER NOT NULL PRIMARY KEY, Nome VARCHAR(85), Latitude REAL, Longitude REAL); ''')
c.execute('''CREATE TABLE REGISTOS (Registo_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE, Humidade FLOAT, Precipitacao FLOAT, Pressao FLOAT, Temperatura FLOAT, Direcao_vento VARCHAR(10), Velocidade_vento FLOAT, Estacao_id INTEGER, Data INTEGER, Hora INTEGER,  FOREIGN KEY('Estacao_id') REFERENCES  ESTACAO(id));''')


# Colocar os dados na Base de Dados

for k in range(len(station)):
    c.execute('INSERT INTO Estacao (ID, Nome, Latitude,Longitude) VALUES (?,?,?,?);' , (station[k][0],station[k][1],latitude[k],longitude[k]))

for k in range(len(matriz_pronta)):
    c.execute('INSERT INTO Registos (Humidade,Precipitacao,Pressao,Temperatura,Direcao_vento,Velocidade_vento,Estacao_id, Data, Hora) VALUES (?,?,?,?,?,?,?,?,?);', (matriz_pronta[k][0] , matriz_pronta[k][1] , matriz_pronta[k][2] , matriz_pronta[k][3] , matriz_pronta[k][4] , matriz_pronta[k][5] , matriz_pronta[k][6], matriz_pronta[k][8] , matriz_pronta[k][9]))

c.execute('''UPDATE REGISTOS SET Temperatura=NULL WHERE Temperatura=-99;''')
c.execute('''UPDATE REGISTOS SET Humidade=NULL WHERE Humidade=-99;''')
c.execute('''UPDATE REGISTOS SET Precipitacao=NULL WHERE Precipitacao=-99;''')
c.execute('''UPDATE REGISTOS SET Pressao=NULL WHERE Pressao=-99;''')
c.execute('''UPDATE REGISTOS SET Direcao_vento=NULL WHERE Direcao_vento='---';''')
c.execute('''UPDATE REGISTOS SET Velocidade_vento=NULL WHERE Velocidade_vento=-99;''')


SqliteConnection.commit()


#Estatisticas

from scipy.stats import mode
from statistics import mean,median,stdev
import numpy as np


#Criamos listas sem os valores nulos e podermos fazer os cáculos estatísticos 

lista_temperatura=[]
for x in c.execute('''SELECT temperatura from Registos where temperatura not null'''):
    lista_temperatura+=x

lista_precipitacao=[]
for x in c.execute('''SELECT precipitacao from Registos where precipitacao not null'''):
    lista_precipitacao+=x


lista_humidade=[]
for x in c.execute('''SELECT Humidade from Registos where humidade not null'''):
    lista_humidade+=x



lista_pressao=[]
for x in c.execute('''SELECT pressao from Registos where pressao not null'''):
    lista_pressao+=x



lista_velcento=[]
for x in c.execute('''SELECT Velocidade_vento from Registos where Velocidade_vento not null'''):
    lista_velcento +=x


lista_dirvento=[]
for x in c.execute('''SELECT Direcao_vento from Registos where Direcao_vento not null'''):
    lista_dirvento+=x




# Médias registos numéricos 
soma = 0
tamanho = 1
for i in lista_temperatura:
    soma += i 
    tamanho += 1
print(round(soma/tamanho))


soma = 0
tamanho = 1
for i in lista_precipitacao:
    soma += i 
    tamanho += 1
print(round(soma/tamanho))



soma = 0
tamanho = 1
for i in lista_humidade:
    soma += i 
    tamanho += 1
print(round(soma/tamanho))



soma = 0
tamanho = 1
for i in lista_pressao:
    soma += i 
    tamanho += 1
print(round(soma/tamanho))



soma = 0
tamanho = 1
for i in lista_velcento:
    soma += i 
    tamanho += 1
print(round(soma/tamanho))


#minimos e máximos
max(lista_temperatura)
min(lista_temperatura)


max(lista_humidade)
min(lista_humidade)


max(lista_pressao)
min(lista_pressao)


max(lista_precipitacao)
min(lista_precipitacao)


max(lista_velcento)
min(lista_velcento)



#como direção do vento é srt fizemos a moda

mode(lista_dirvento)


#Estatística usando o pandas para termos mais informações estatísticas

import pandas as pd
df1 = pd.read_csv("ipma_201508.csv")

df1['humidity'].describe()
df1['precipitation'].describe()
df1['pressure'].describe()
df1['temperature'].describe()
df1['windDirection'].describe()
df1['windSpeed'].describe()

df1['stationName'].value_counts() #número de estações diferentes


#Gráficos 


# Para conseguir fazer os gráficos achamos mais prático criar listas com NAs que haviamos retirado acima



lista_temperatura_NA=[]
for x in c.execute('''SELECT temperatura from Registos'''):
    lista_temperatura_NA+= [x]

lista_precipitacao_NA=[]
for x in c.execute('''SELECT precipitacao from Registos '''):
    lista_precipitacao_NA+=[x]


lista_humidade_NA=[]
for x in c.execute('''SELECT Humidade from Registos '''):
    lista_humidade_NA+=[x]



lista_pressao_NA=[]
for x in c.execute('''SELECT pressao from Registos'''):
    lista_pressao_NA+=[x]



lista_velcento_NA=[]
for x in c.execute('''SELECT Velocidade_vento from Registos '''):
    lista_velcento_NA +=[x]


lista_dirvento_NA=[]
for x in c.execute('''SELECT Direcao_vento from Registos l'''):
    lista_dirvento_NA+=[x]


estação=[]
for x in c.execute('''SELECT nome from estacao''') :
    estação+= [x]




#### Um segundo código para a mesma coisa
lista_temperatura = []
lista_humidade = []
lista_pressao = []
for temperatura, humidade, pressao in c.execute('''SELECT temperatura, humidade, pressao from Registos where temperatura not null AND humidade NOT NULL AND pressao NOT NULL'''):
    lista_temperatura += [temperatura]
    lista_humidade += [humidade]
    lista_pressao += [pressao]

## Gráficos

#Gráficos
    
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
import numpy as np 


x=np.array(list(range(len(lista_temperatura_NA))))
y=np.array(lista_temperatura_NA)

plt.scatter(x, y)
plt.show()


x=np.array(list(range(len(lista_pressao_NA))))
y=np.array(lista_pressao_NA)

plt.scatter(x, y)
plt.show()


x=np.array(list(range(len(lista_velcento_NA))))
y=np.array(lista_velcento_NA)

plt.scatter(x, y)
plt.show()



#FIM DO CÓDIGO 